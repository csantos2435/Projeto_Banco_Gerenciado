const mysql = require('mysql2/promise');

const PRIMARY_HOST = '34.23.151.195';
const REPLICA_HOST = '34.23.200.142';
const DATABASE = 'aula-db';
const USER = 'seu_usuario';
const PASSWORD = 'sua_senha';
const CRIADO_POR = 'marketing@serjava'; // Nome do grupo para o campo 'criado_por'

// Conexão com o host primário (para inserções)
const primaryConnection = mysql.createPool({
  host: PRIMARY_HOST,
  user: USER,
  password: PASSWORD,
  database: DATABASE
});

// Conexão com a réplica (para seleções)
const replicaConnection = mysql.createPool({
  host: REPLICA_HOST,
  user: USER,
  password: PASSWORD,
  database: DATABASE
});

// Função para inserir um produto
async function insertProduct() {
  const descricao = `Produto_${Math.floor(Math.random() * 1000)}`;
  const categoria = `Cat${Math.floor(Math.random() * 10)}`;
  const valor = (Math.random() * 1000).toFixed(2);

  const query = `
    INSERT INTO produto (descricao, categoria, valor, criado_por)
    VALUES (?, ?, ?, ?)
  `;
  const [result] = await primaryConnection.execute(query, [
    descricao, categoria, valor, CRIADO_POR
  ]);

  console.log(`Inserido: ID ${result.insertId}, ${descricao}, ${categoria}, ${valor}`);
  return result.insertId;
}

// Função para buscar um produto por ID
async function selectProductById(id) {
  const query = `SELECT * FROM produto WHERE id = ?`;
  const [rows] = await replicaConnection.execute(query, [id]);
  if (rows.length > 0) {
    console.log(`Produto ID ${id}:`, rows[0]);
  } else {
    console.log(`Produto ID ${id} não encontrado`);
  }
}

// Função principal que realiza as inserções e seleções
async function main() {
  while (true) {
    try {
      // Realiza o insert e obtém o ID do produto inserido
      const lastInsertId = await insertProduct();

      // Realiza 10 selects para os IDs anteriores
      for (let i = lastInsertId - 1; i > lastInsertId - 11 && i > 0; i--) {
        await selectProductById(i);
      }

      // Intervalo de 1 segundo antes do próximo loop
      await new Promise(resolve => setTimeout(resolve, 1000));
    } catch (error) {
      console.error('Erro durante a operação:', error);
    }
  }
}

// Executa a função principal
main();
